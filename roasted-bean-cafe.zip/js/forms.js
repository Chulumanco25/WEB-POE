'use strict';

/* ===== Settings: edit these to match your café ===== */
const RECIPIENT = 'info@roastedbeancafe.example'; // your real address
const FORM_ENDPOINT = ''; // optional Formspree URL, e.g. 'https://formspree.io/f/abcd1234'
const CLOSED_DAY = 0;     // 0 = Sunday
const PRICES = {
  catering: { label: 'Catering', qtyLabel: 'Number of guests', price: 85, min: 10, leadDays: 3 },
  beans:    { label: 'Coffee beans (250 g bags)', qtyLabel: 'Number of bags', price: 95, min: 1, leadDays: 1 },
  venue:    { label: 'Venue hire (per hour)', qtyLabel: 'Hours needed', price: 450, min: 2, leadDays: 7 }
};

/* ===== Helpers ===== */
const el = (tag, text) => { const n = document.createElement(tag); n.textContent = text; return n; };
const money = n => new Intl.NumberFormat('en-ZA', { style: 'currency', currency: 'ZAR' }).format(n);
const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
const parseDate = iso => new Date(iso + 'T00:00:00');
const toISO = d => new Date(d - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
const setStatus = (box, kind, text) => { box.className = 'form-status status-' + kind; box.textContent = text; };

/* ===== Validation rules: each returns '' (valid) or an error message ===== */
const chooseOne = v => (v ? '' : 'Choose an option from the list.');
const RULES = {
  fullName: v => !v.trim() ? 'Enter your full name.'
    : !/^[A-Za-zÀ-ÿ' -]{2,60}$/.test(v.trim()) ? 'Use 2–60 letters, spaces, hyphens or apostrophes.' : '',
  email: v => !v.trim() ? 'Enter your email address.'
    : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.trim()) ? 'Enter an email like name@example.com.' : '',
  phone: v => !v.trim() ? 'Enter your phone number.'
    : !/^(\+27|0)\d{9}$/.test(v.replace(/[\s-]/g, '')) ? 'Enter a South African number like 082 123 4567.' : '',
  enquiryType: chooseOne,
  messageType: chooseOne,
  quantity: (v, form) => {
    const t = PRICES[form.elements.enquiryType.value], n = Number(v);
    if (!v.trim()) return 'Enter a quantity.';
    if (!Number.isInteger(n) || n < 1) return 'Enter a whole number, 1 or more.';
    if (t && n < t.min) return 'The minimum for ' + t.label.toLowerCase() + ' is ' + t.min + '.';
    if (n > 500) return 'For more than 500, use the contact page.';
    return '';
  },
  date: v => !v ? 'Choose a date.' : parseDate(v) < startOfToday() ? 'Choose today or a future date.' : '',
  contactMethod: v => (v ? '' : 'Choose how we should reply.'),
  notes: v => (v.length > 500 ? 'Keep notes to 500 characters or fewer.' : ''),
  message: v => {
    const len = v.trim().length;
    return len < 10 ? 'Write at least 10 characters.' : len > 500 ? 'Keep your message to 500 characters or fewer.' : '';
  },
  consent: v => (v ? '' : 'Tick the box so we can contact you.')
};

function getValue(form, name) {
  const field = form.elements[name];
  if (!field) return '';
  if (field instanceof RadioNodeList) return field.value;
  return field.type === 'checkbox' ? (field.checked ? field.value : '') : field.value;
}

function showError(form, name, msg) {
  const out = form.querySelector('#' + name + '-error');
  const group = out && out.closest('.form-group');
  if (out) out.textContent = msg;
  if (group) group.classList.toggle('has-error', Boolean(msg));
  const field = form.elements[name];
  const first = field instanceof RadioNodeList ? field[0] : field;
  if (first) first.setAttribute('aria-invalid', msg ? 'true' : 'false');
}

function validateField(form, name) {
  const msg = RULES[name](getValue(form, name), form);
  showError(form, name, msg);
  return msg;
}

function validateForm(form) {
  const bad = Object.keys(RULES).filter(n => form.elements[n] && validateField(form, n));
  if (bad.length) {
    const f = form.elements[bad[0]];
    (f instanceof RadioNodeList ? f[0] : f).focus();
  }
  return bad.length === 0;
}

function wireValidation(form) {
  const check = e => { if (e.target.name in RULES) validateField(form, e.target.name); };
  form.addEventListener('focusout', check);
  form.addEventListener('change', check);
  form.addEventListener('input', e => {
    const group = e.target.closest('.form-group');
    if (e.target.name in RULES && group && group.classList.contains('has-error')) validateField(form, e.target.name);
  });
}

/* ===== Enquiry form: validate, then show a cost and availability response ===== */
function showQuote(form) {
  const f = form.elements;
  const t = PRICES[f.enquiryType.value];
  const qty = Number(f.quantity.value);
  const date = parseDate(f.date.value);
  const daysAhead = Math.round((date - startOfToday()) / 86400000);
  const closed = date.getDay() === CLOSED_DAY;
  const tooSoon = daysAhead < t.leadDays;
  const nice = date.toLocaleDateString('en-ZA', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' });
  const method = f.contactMethod.value === 'phone' ? 'phone call' : 'email';
  const msg = closed ? 'We are closed on that day, so please choose another date.'
    : tooSoon ? 'We need at least ' + t.leadDays + ' days’ notice for this. Please choose a later date.'
    : 'Good news: ' + nice + ' is available.';

  const out = form.querySelector('#enquiry-result');
  out.replaceChildren(
    el('h3', 'Thanks, ' + f.fullName.value.trim().split(/\s+/)[0] + '. Here is your estimate.'),
    el('p', t.label + ': ' + qty + ' × ' + money(t.price) + ' = ' + money(qty * t.price)),
    el('p', msg),
    el('p', 'We will reply by ' + method + ' within one working day.')
  );
  out.className = 'result ' + (closed || tooSoon ? 'result-warn' : 'result-ok');
  out.hidden = false;
  out.focus();
}

function initEnquiry(form) {
  const type = form.elements.enquiryType, label = form.querySelector('#quantity-label');
  form.elements.date.min = toISO(new Date());
  type.addEventListener('change', () => {
    const t = PRICES[type.value];
    label.textContent = t ? t.qtyLabel : 'Quantity';
    if (form.elements.quantity.value) validateField(form, 'quantity');
  });
  form.addEventListener('submit', e => {
    e.preventDefault();
    if (validateForm(form)) showQuote(form);
  });
}

/* ===== Contact form: validate, then email it (Formspree if set, otherwise mailto) ===== */
function initContact(form) {
  const msg = form.elements.message, count = form.querySelector('#message-count');
  const status = form.querySelector('#contact-status'), btn = form.querySelector('button[type="submit"]');
  const update = () => { count.textContent = msg.value.length + '/500'; };
  msg.addEventListener('input', update);
  update();

  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (!validateForm(form)) return;
    const d = Object.fromEntries(new FormData(form));
    const subject = '[' + d.messageType + '] Message from ' + d.fullName;
    const body = ['Name: ' + d.fullName, 'Email: ' + d.email, 'Phone: ' + d.phone, 'Type: ' + d.messageType, '', d.message].join('\n');

    if (!FORM_ENDPOINT) {
      window.location.href = 'mailto:' + RECIPIENT + '?subject=' + encodeURIComponent(subject) + '&body=' + encodeURIComponent(body);
      setStatus(status, 'success', 'Your email app should open with the message ready. Press Send to finish. If nothing opens, email us at ' + RECIPIENT + '.');
      return;
    }
    btn.disabled = true;
    setStatus(status, 'info', 'Sending your message…');
    try {
      const res = await fetch(FORM_ENDPOINT, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ ...d, _subject: subject })
      });
      if (!res.ok) throw new Error('HTTP ' + res.status);
      form.reset();
      update();
      setStatus(status, 'success', 'Message sent. We will reply within one working day.');
    } catch (err) {
      setStatus(status, 'error', 'The message did not send. Check your connection and try again, or email ' + RECIPIENT + '.');
    } finally {
      btn.disabled = false;
    }
  });
}

const enquiryForm = document.getElementById('enquiry-form');
const contactForm = document.getElementById('contact-form');
[enquiryForm, contactForm].forEach(f => f && wireValidation(f));
if (enquiryForm) initEnquiry(enquiryForm);
if (contactForm) initContact(contactForm);
