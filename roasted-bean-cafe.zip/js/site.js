(() => {
  const $ = (s, r = document) => r.querySelector(s);
  const make = (t, c, x) => { const n = document.createElement(t); if (c) n.className = c; if (x !== undefined) n.textContent = x; return n; };

  const tog = $('.nav-toggle'), nav = $('#nav');
  tog.addEventListener('click', () => tog.setAttribute('aria-expanded', nav.classList.toggle('open')));

  const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => {
    if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
  }), { threshold: 0.15 }) : null;
  document.querySelectorAll('.reveal').forEach(n => (io ? io.observe(n) : n.classList.add('in')));

  const all = document.querySelectorAll('.accordion details');
  all.forEach(d => d.addEventListener('toggle', () => { if (d.open) all.forEach(o => { if (o !== d) o.open = false; }); }));

  const dlg = $('#how-dialog');
  if (dlg) {
    $('#how-btn').addEventListener('click', () => dlg.showModal());
    dlg.addEventListener('click', e => { if (e.target === dlg || e.target.matches('.close')) dlg.close(); });
  }

  const links = [...document.querySelectorAll('[data-lightbox]')];
  if (links.length) {
    let i = 0, box, img, cap;
    const show = n => { i = (n + links.length) % links.length; img.src = links[i].href; img.alt = links[i].querySelector('img').alt; cap.textContent = img.alt; };
    const keys = e => { if (e.key === 'Escape') close(); if (e.key === 'ArrowRight') show(i + 1); if (e.key === 'ArrowLeft') show(i - 1); };
    const close = () => { box.hidden = true; document.removeEventListener('keydown', keys); links[i].focus(); };
    const btn = (t, c, f, l) => { const b = make('button', c, t); b.type = 'button'; b.setAttribute('aria-label', l); b.addEventListener('click', e => { e.stopPropagation(); f(); }); return b; };
    const build = () => {
      box = make('div', 'lightbox'); box.setAttribute('role', 'dialog'); box.setAttribute('aria-modal', 'true'); box.setAttribute('aria-label', 'Image viewer');
      img = make('img'); cap = make('p');
      box.append(btn('×', 'lb-close', close, 'Close'), btn('‹', 'lb-prev', () => show(i - 1), 'Previous image'), img, btn('›', 'lb-next', () => show(i + 1), 'Next image'), cap);
      box.addEventListener('click', e => { if (e.target === box) close(); });
      document.body.append(box);
    };
    links.forEach((a, n) => a.addEventListener('click', e => {
      e.preventDefault(); if (!box) build();
      box.hidden = false; show(n); document.addEventListener('keydown', keys); $('.lb-close', box).focus();
    }));
  }

  const list = $('#menu-list');
  if (list) {
    const search = $('#menu-search'), sort = $('#menu-sort'), tabs = $('#menu-tabs'), none = $('#menu-empty');
    let items = [], cat = 'All';
    const money = n => new Intl.NumberFormat('en-ZA', { style: 'currency', currency: 'ZAR' }).format(n);
    const draw = () => {
      const q = search.value.trim().toLowerCase();
      const rows = items.filter(m => (cat === 'All' || m.category === cat) && (m.name + ' ' + m.desc).toLowerCase().includes(q));
      rows.sort(sort.value === 'price' ? (a, b) => a.price - b.price : (a, b) => a.name.localeCompare(b.name));
      list.replaceChildren(...rows.map(m => { const li = make('li', 'card'); li.append(make('h3', '', m.name), make('p', '', m.desc), make('strong', '', money(m.price))); return li; }));
      none.hidden = rows.length > 0;
    };
    fetch('data/menu.json').then(r => r.json()).then(d => {
      items = d;
      ['All', ...new Set(d.map(m => m.category))].forEach((c, n) => {
        const b = make('button', '', c); b.type = 'button'; b.setAttribute('role', 'tab'); b.setAttribute('aria-selected', String(n === 0));
        b.addEventListener('click', () => { cat = c; tabs.querySelectorAll('button').forEach(x => x.setAttribute('aria-selected', String(x === b))); draw(); });
        tabs.append(b);
      });
      draw();
    }).catch(() => { none.hidden = false; none.textContent = 'The menu could not load. Open the site from a web server or the live link, not directly from a file.'; });
    search.addEventListener('input', draw); sort.addEventListener('change', draw);
  }

  if ($('#map') && window.L) {
    const p = [-33.9249, 18.4241]; // set to your café's latitude and longitude
    const m = L.map('map').setView(p, 15);
    L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', { maxZoom: 19, attribution: '© OpenStreetMap contributors' }).addTo(m);
    L.marker(p).addTo(m).bindPopup('<strong>Roasted Bean Cafe</strong><br>12 Bean Street').openPopup();
  }
})();
