# Roasted Bean Cafe

Static 8-page café website (Part 3 POE). Live site: [add link] | Repository: [add link]

## Pages
index, about (gallery with lightbox), menu (JSON-driven search, filter, sort and category tabs), order (modal), reservations, enquiry (form with quote response), contact (Leaflet map and email form), faq (accordion).

## Run locally
Use VS Code Live Server (the menu uses `fetch()`, which does not work from `file://`).

## SEO
Unique title, description and keywords on every page; descriptive image file names with alt text; robots.txt and sitemap.xml (replace `YOUR-LIVE-URL` after deploying).

## Forms
Both forms use `js/forms.js`: field-level validation with inline messages, an enquiry estimate with availability check, and a contact email sent through Formspree (if `FORM_ENDPOINT` is set) or `mailto:`.

## Changelog
**Part 2 feedback**
- [date] [Describe how you updated the proposal and removed unfinished wording; name the files.]
- [date] [Describe the Git history now in the repository.]

**Part 3**
- [date] Added enquiry and contact forms with JavaScript validation (`enquiry.html`, `contact.html`, `js/forms.js`).
- [date] Added JSON menu with search, filter and sort (`menu.html`, `data/menu.json`, `js/site.js`).
- [date] Added tabs, accordion, modal, lightbox and Leaflet map.
- [date] Added SEO tags, robots.txt and sitemap.xml to all pages.

## References
[Add your Harvard-style references: Leaflet, MDN Web Docs, Google Search Central, sitemaps.org, Formspree or EmailJS, your hosting platform, image sources.]
